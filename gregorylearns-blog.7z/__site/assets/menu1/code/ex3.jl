# This file was generated, do not modify it. # hide
using Random
Random.seed!(1) # hide
@show randn(2)